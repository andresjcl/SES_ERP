﻿Imports WebServiceSri

Public Class Form1

    Private Function getXML() As String
        Dim open As New OpenFileDialog
        Dim retVal As String = String.Empty
        '--------------------------------------------------------------------------------------------
        open.Filter = "Archivos XML(*.xml)|*.xml"
        '--------------------------------------------------------------------------------------------
        If open.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            retVal = open.FileName
        End If
        '--------------------------------------------------------------------------------------------
        getXML = retVal
        '--------------------------------------------------------------------------------------------
        open = Nothing
    End Function

    Private Function sendComprobante01(ByVal fileNameXML As String, ByVal fileResponseSRI As String) As Boolean
        Dim rs As WebServiceSri.RespuestaSRYType = RespuestaSRYType.NOAUTORIZADO
        Dim ws As New WebServiceSri.WebService
        '--------------------------------------------------------------------------------------------
        ws.IsOFFLine = True
        '--------------------------------------------------------------------------------------------
        rs = ws.SendComprobante(fileNameXML, fileResponseSRI)
        '--------------------------------------------------------------------------------------------
        If rs = RespuestaSRYType.AUTORIZADO Then
            MsgBox(ws.Comprobante.NumeroAutorizacion + "  " + ws.Comprobante.FechaAutorizacion)
        ElseIf rs = RespuestaSRYType.PENDIENTE Then
            MsgBox("Pendiente de autorizacion: " + ws.Comprobante.getMensajes)
        ElseIf rs = RespuestaSRYType.NOAUTORIZADO Then
            MsgBox("No autorizado: " + ws.Comprobante.getMensajes)
        Else
            MsgBox("Sin Conexion: " + ws.Comprobante.getMensajes)
        End If
        '--------------------------------------------------------------------------------------------
        ws = Nothing
    End Function

    Private Function sendComprobante02(ByVal fileNameXML As String, ByVal fileResponseSRI As String) As Boolean
        Dim rs As WebServiceSri.RespuestaSRYType = RespuestaSRYType.NOAUTORIZADO
        Dim ws As New WebServiceSri.WebService
        '--------------------------------------------------------------------------------------------
        ws.IsOFFLine = True
        '--------------------------------------------------------------------------------------------
        rs = ws.SendComprobante(fileNameXML, fileResponseSRI)
        '--------------------------------------------------------------------------------------------
        If rs = RespuestaSRYType.AUTORIZADO Then
            MsgBox(ws.Comprobante.NumeroAutorizacion + "  " + ws.Comprobante.FechaAutorizacion)
        Else
            MsgBox("Error : " + ws.Comprobante.getMensajes)
        End If
        '--------------------------------------------------------------------------------------------
        ws = Nothing
    End Function

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        
    End Sub

End Class
